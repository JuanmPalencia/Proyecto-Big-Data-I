import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider } from "@/i18n/LanguageContext";
import { SubscriptionProvider } from "@/contexts/SubscriptionContext";
import { Layout } from "@/components/Layout";
import Index from "./pages/Index";
import Servicios from "./pages/Servicios";
import DashboardUrbano from "./pages/DashboardUrbano";
import DashboardInversion from "./pages/DashboardInversion";
import Precios from "./pages/Precios";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <LanguageProvider>
        <SubscriptionProvider>
        <BrowserRouter>
          <Layout>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/servicios" element={<Servicios />} />
              <Route path="/dashboard-urbano" element={<DashboardUrbano />} />
              <Route path="/dashboard-inversion" element={<DashboardInversion />} />
              <Route path="/precios" element={<Precios />} />
              <Route path="/auth" element={<Auth />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Layout>
        </BrowserRouter>
        </SubscriptionProvider>
      </LanguageProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
