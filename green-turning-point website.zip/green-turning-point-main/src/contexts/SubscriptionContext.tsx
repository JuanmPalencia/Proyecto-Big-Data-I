import { createContext, useContext, useState, ReactNode } from "react";

interface SubscriptionContextType {
  isSubscribed: boolean;
  planName: string | null;
  subscribe: (plan: string) => void;
}

const SubscriptionContext = createContext<SubscriptionContextType>({
  isSubscribed: false,
  planName: null,
  subscribe: () => {},
});

export function SubscriptionProvider({ children }: { children: ReactNode }) {
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [planName, setPlanName] = useState<string | null>(null);

  const subscribe = (plan: string) => {
    setPlanName(plan);
    setIsSubscribed(true);
  };

  return (
    <SubscriptionContext.Provider value={{ isSubscribed, planName, subscribe }}>
      {children}
    </SubscriptionContext.Provider>
  );
}

export const useSubscription = () => useContext(SubscriptionContext);
