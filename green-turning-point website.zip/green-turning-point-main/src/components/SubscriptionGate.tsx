import { useSubscription } from "@/contexts/SubscriptionContext";
import { useLanguage } from "@/i18n/LanguageContext";
import { Button } from "@/components/ui/button";
import { Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function SubscriptionGate({ children }: { children: React.ReactNode }) {
  const { isSubscribed } = useSubscription();
  const { t } = useLanguage();
  const navigate = useNavigate();

  if (isSubscribed) {
    return <>{children}</>;
  }

  return (
    <div className="relative">
      <div className="blur-sm pointer-events-none select-none" aria-hidden="true">
        {children}
      </div>
      <div className="absolute inset-0 flex items-center justify-center z-10">
        <div className="text-center bg-background/80 backdrop-blur-sm border rounded-2xl p-8 max-w-md mx-4 animate-fade-in shadow-xl">
          <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <Lock className="h-7 w-7 text-primary" />
          </div>
          <h2 className="text-xl font-bold mb-2">{t("gate.title")}</h2>
          <p className="text-sm text-muted-foreground mb-6">{t("gate.subtitle")}</p>
          <Button variant="hero" onClick={() => navigate("/precios")} className="gap-2">
            {t("gate.cta")}
          </Button>
        </div>
      </div>
    </div>
  );
}
