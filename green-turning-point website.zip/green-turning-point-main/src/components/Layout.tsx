import { Navbar } from "./Navbar";
import { useLanguage } from "@/i18n/LanguageContext";

export function Layout({ children }: { children: React.ReactNode }) {
  const { t } = useLanguage();
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">{children}</main>
      <footer className="border-t py-8">
        <div className="container text-center text-sm text-muted-foreground">
          {t("footer.rights")}
        </div>
      </footer>
    </div>
  );
}
