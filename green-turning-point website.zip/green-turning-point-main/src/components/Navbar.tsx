import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X, Leaf, Globe, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/i18n/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";

const navKeys = [
  { key: "nav.inicio", path: "/" },
  { key: "nav.servicios", path: "/servicios" },
  { key: "nav.dashboardUrbano", path: "/dashboard-urbano" },
  { key: "nav.dashboardInversion", path: "/dashboard-inversion" },
  { key: "nav.precios", path: "/precios" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const location = useLocation();
  const navigate = useNavigate();
  const { lang, setLang, t } = useLanguage();

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });
    return () => subscription.unsubscribe();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate("/");
  };

  return (
    <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-lg">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2 font-bold text-lg">
          <Leaf className="h-6 w-6 text-primary" />
          <span>GTP</span>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {navKeys.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "px-3 py-2 rounded-md text-sm font-medium transition-colors hover:text-primary",
                location.pathname === item.path ? "text-primary bg-accent" : "text-muted-foreground"
              )}
            >
              {t(item.key)}
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-2">
          <ThemeToggle />
          <button
            onClick={() => setLang(lang === "es" ? "en" : "es")}
            className="flex items-center gap-1 px-2 py-1.5 rounded-md text-xs font-semibold hover:bg-accent text-muted-foreground transition-colors"
            aria-label="Toggle language"
          >
            <Globe className="h-3.5 w-3.5" />
            {lang === "es" ? "EN" : "ES"}
          </button>
          {user ? (
            <>
              <span className="text-xs text-muted-foreground truncate max-w-[120px]">{user.email}</span>
              <Button variant="outline" size="sm" onClick={handleLogout} className="gap-1">
                <LogOut className="h-3.5 w-3.5" />
                {t("auth.logout")}
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" size="sm" onClick={() => navigate("/auth")}>
                {t("nav.login")}
              </Button>
              <Button variant="hero" size="sm" onClick={() => navigate("/auth")}>
                {t("nav.register")}
              </Button>
            </>
          )}
        </div>

        <div className="flex md:hidden items-center gap-2">
          <ThemeToggle />
          <button
            onClick={() => setLang(lang === "es" ? "en" : "es")}
            className="p-2 rounded-md text-xs font-semibold hover:bg-accent text-muted-foreground"
          >
            <Globe className="h-4 w-4" />
          </button>
          <button onClick={() => setOpen(!open)} className="p-2">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="md:hidden border-t bg-background p-4 space-y-1">
          {navKeys.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setOpen(false)}
              className={cn(
                "block px-3 py-2 rounded-md text-sm font-medium transition-colors",
                location.pathname === item.path ? "text-primary bg-accent" : "text-muted-foreground hover:text-primary"
              )}
            >
              {t(item.key)}
            </Link>
          ))}
          <div className="flex gap-2 mt-2">
            {user ? (
              <Button variant="outline" size="sm" className="flex-1 gap-1" onClick={() => { setOpen(false); handleLogout(); }}>
                <LogOut className="h-3.5 w-3.5" />
                {t("auth.logout")}
              </Button>
            ) : (
              <>
                <Button variant="outline" size="sm" className="flex-1" onClick={() => { setOpen(false); navigate("/auth"); }}>
                  {t("nav.login")}
                </Button>
                <Button variant="hero" size="sm" className="flex-1" onClick={() => { setOpen(false); navigate("/auth"); }}>
                  {t("nav.register")}
                </Button>
              </>
            )}
          </div>
        </nav>
      )}
    </header>
  );
}

function ThemeToggle() {
  const toggle = () => {
    document.documentElement.classList.toggle("dark");
  };
  return (
    <button onClick={toggle} className="p-2 rounded-md hover:bg-accent text-muted-foreground" aria-label="Toggle theme">
      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
      </svg>
    </button>
  );
}
