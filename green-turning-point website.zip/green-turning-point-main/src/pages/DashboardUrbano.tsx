import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Leaf, Wind, TreePine, DollarSign } from "lucide-react";
import { SubscriptionGate } from "@/components/SubscriptionGate";
import { useLanguage } from "@/i18n/LanguageContext";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  ScatterChart, Scatter, ResponsiveContainer,
  ReferenceLine, Label,
} from "recharts";

const cityData: Record<string, {
  ndvi: number; no2: number; reforest: number; pib: number;
  kuznets: { pib: number; degradation: number }[];
  scatter: { pib: number; no2: number }[];
}> = {
  Madrid: {
    ndvi: 0.75, no2: 25.3, reforest: 45, pib: 42000,
    kuznets: [
      { pib: 15000, degradation: 30 }, { pib: 20000, degradation: 55 },
      { pib: 25000, degradation: 72 }, { pib: 30000, degradation: 80 },
      { pib: 35000, degradation: 75 }, { pib: 40000, degradation: 60 },
      { pib: 42000, degradation: 48 },
    ],
    scatter: [
      { pib: 15000, no2: 18 }, { pib: 22000, no2: 32 }, { pib: 28000, no2: 38 },
      { pib: 33000, no2: 35 }, { pib: 38000, no2: 28 }, { pib: 42000, no2: 25.3 },
    ],
  },
  Barcelona: {
    ndvi: 0.68, no2: 30.1, reforest: 38, pib: 39000,
    kuznets: [
      { pib: 14000, degradation: 28 }, { pib: 19000, degradation: 50 },
      { pib: 24000, degradation: 68 }, { pib: 29000, degradation: 78 },
      { pib: 34000, degradation: 73 }, { pib: 39000, degradation: 58 },
    ],
    scatter: [
      { pib: 14000, no2: 20 }, { pib: 20000, no2: 35 }, { pib: 26000, no2: 42 },
      { pib: 32000, no2: 38 }, { pib: 39000, no2: 30.1 },
    ],
  },
  Valencia: {
    ndvi: 0.72, no2: 22.8, reforest: 52, pib: 35000,
    kuznets: [
      { pib: 12000, degradation: 25 }, { pib: 17000, degradation: 48 },
      { pib: 22000, degradation: 65 }, { pib: 27000, degradation: 70 },
      { pib: 32000, degradation: 62 }, { pib: 35000, degradation: 45 },
    ],
    scatter: [
      { pib: 12000, no2: 15 }, { pib: 18000, no2: 28 }, { pib: 24000, no2: 35 },
      { pib: 30000, no2: 30 }, { pib: 35000, no2: 22.8 },
    ],
  },
  Sevilla: {
    ndvi: 0.65, no2: 28.7, reforest: 35, pib: 31000,
    kuznets: [
      { pib: 10000, degradation: 22 }, { pib: 15000, degradation: 45 },
      { pib: 20000, degradation: 62 }, { pib: 25000, degradation: 68 },
      { pib: 31000, degradation: 55 },
    ],
    scatter: [
      { pib: 10000, no2: 14 }, { pib: 16000, no2: 30 }, { pib: 22000, no2: 38 },
      { pib: 28000, no2: 33 }, { pib: 31000, no2: 28.7 },
    ],
  },
  Bilbao: {
    ndvi: 0.80, no2: 19.5, reforest: 60, pib: 44000,
    kuznets: [
      { pib: 18000, degradation: 35 }, { pib: 24000, degradation: 58 },
      { pib: 30000, degradation: 74 }, { pib: 36000, degradation: 68 },
      { pib: 40000, degradation: 52 }, { pib: 44000, degradation: 38 },
    ],
    scatter: [
      { pib: 18000, no2: 22 }, { pib: 25000, no2: 34 }, { pib: 32000, no2: 30 },
      { pib: 38000, no2: 24 }, { pib: 44000, no2: 19.5 },
    ],
  },
};

const cities = Object.keys(cityData);
const years = ["2020", "2021", "2022", "2023", "2024", "2025"];

const kuznetsConfig = {
  degradation: { label: "Degradación Ambiental", color: "hsl(var(--primary))" },
};
const scatterConfig = {
  no2: { label: "NO₂ (µg/m³)", color: "hsl(var(--primary))" },
};

export default function DashboardUrbano() {
  const { t } = useLanguage();
  const [selectedCity, setSelectedCity] = useState("Madrid");
  const [selectedYear, setSelectedYear] = useState("2025");

  const data = cityData[selectedCity];

  const kpis = [
    { icon: Leaf, label: t("du.ndvi"), value: data.ndvi.toFixed(2), desc: t("du.ndviDesc") },
    { icon: Wind, label: t("du.no2"), value: `${data.no2} µg/m³`, desc: t("du.no2Desc") },
    { icon: TreePine, label: t("du.reforest"), value: `${data.reforest}%`, desc: t("du.reforestDesc") },
    { icon: DollarSign, label: t("du.pib"), value: `€${data.pib.toLocaleString()}`, desc: t("du.pibDesc") },
  ];

  return (
    <SubscriptionGate>
    <div className="container py-10 md:py-16">
      <div className="max-w-2xl mb-8">
        <span className="text-sm font-medium text-primary">{t("du.label")}</span>
        <h1 className="text-3xl md:text-5xl font-bold mt-2">{t("du.title")}</h1>
        <p className="text-muted-foreground mt-3">{t("du.subtitle")}</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Sidebar Filters */}
        <aside className="lg:w-56 shrink-0 space-y-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">{t("du.filters")}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">{t("du.city")}</label>
                <Select value={selectedCity} onValueChange={setSelectedCity}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {cities.map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">{t("du.year")}</label>
                <Select value={selectedYear} onValueChange={setSelectedYear}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {years.map((y) => (
                      <SelectItem key={y} value={y}>{y}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </aside>

        {/* Main content */}
        <div className="flex-1 space-y-6">
          {/* KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {kpis.map((k) => (
              <Card key={k.label}>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-xs font-medium text-muted-foreground">{k.label}</CardTitle>
                  <k.icon className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{k.value}</div>
                  <p className="text-xs text-muted-foreground mt-1">{k.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Charts */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Kuznets Curve */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">{t("du.kuznets")}</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer config={kuznetsConfig} className="h-[280px] w-full">
                  <LineChart data={data.kuznets} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                    <XAxis dataKey="pib" tickFormatter={(v) => `€${(v / 1000).toFixed(0)}k`} className="text-[10px]" />
                    <YAxis className="text-[10px]" />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Line
                      type="monotone"
                      dataKey="degradation"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={{ fill: "hsl(var(--primary))", r: 4 }}
                    />
                    <ReferenceLine y={50} stroke="hsl(var(--destructive))" strokeDasharray="4 4">
                      <Label value={t("du.turningPoint")} position="right" className="text-[10px] fill-destructive" />
                    </ReferenceLine>
                  </LineChart>
                </ChartContainer>
              </CardContent>
            </Card>

            {/* GDP vs NO2 Scatter */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">{t("du.scatterTitle")}</CardTitle>
              </CardHeader>
              <CardContent>
                <ChartContainer config={scatterConfig} className="h-[280px] w-full">
                  <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                    <XAxis dataKey="pib" name="PIB" tickFormatter={(v) => `€${(v / 1000).toFixed(0)}k`} className="text-[10px]" />
                    <YAxis dataKey="no2" name="NO₂" unit=" µg/m³" className="text-[10px]" />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Scatter
                      name="NO₂"
                      data={data.scatter}
                      fill="hsl(var(--primary))"
                      fillOpacity={0.8}
                    />
                  </ScatterChart>
                </ChartContainer>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
    </SubscriptionGate>
  );
}
