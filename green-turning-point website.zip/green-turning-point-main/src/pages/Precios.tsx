import { useState } from "react";
import { Check, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { useLanguage } from "@/i18n/LanguageContext";
import { useSubscription } from "@/contexts/SubscriptionContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

export default function Precios() {
  const { t } = useLanguage();
  const { subscribe, isSubscribed } = useSubscription();
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);

  const plans = [
    {
      name: "Explorer",
      price: "$29",
      period: "/mes",
      desc: t("precios.starterDesc"),
      features: ["Dashboard básico", "5 alertas/día", "10 ciudades", "Soporte email"],
      featured: false,
    },
    {
      name: "Investor",
      price: "$99",
      period: "/mes",
      desc: t("precios.proDesc"),
      features: ["Dashboards completos", "Alertas ilimitadas", "40+ ciudades", "API access", "Soporte prioritario"],
      featured: true,
    },
    {
      name: "Institutional",
      price: "Custom",
      period: "",
      desc: t("precios.enterpriseDesc"),
      features: ["Todo en Investor", "White-label", "Datos privados", "SLA dedicado", "Account manager"],
      featured: false,
    },
  ];

  const handleSelectPlan = (planName: string) => {
    if (planName === "Institutional") return;
    setSelectedPlan(planName);
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate registration/payment
    await new Promise((r) => setTimeout(r, 1500));
    subscribe(selectedPlan!);
    setDialogOpen(false);
    setLoading(false);
    toast({
      title: t("precios.successTitle"),
      description: `${t("precios.successDesc")} ${selectedPlan}`,
    });
  };

  return (
    <div className="container py-16 md:py-24">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-sm font-medium text-primary">{t("precios.label")}</span>
        <h1 className="text-3xl md:text-5xl font-bold mt-2">{t("precios.title")}</h1>
        <p className="text-muted-foreground mt-4">{t("precios.subtitle")}</p>
      </div>

      <div id="pricing-table" className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {plans.map((p) => (
          <div
            key={p.name}
            className={cn(
              "rounded-xl border p-8 flex flex-col transition-all hover:shadow-lg",
              p.featured ? "border-primary bg-accent/30 glow-primary relative" : "bg-card"
            )}
          >
            {p.featured && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 text-xs font-semibold bg-primary text-primary-foreground px-3 py-1 rounded-full">
                {t("precios.popular")}
              </span>
            )}
            <h3 className="text-lg font-semibold">{p.name}</h3>
            <div className="mt-4 mb-2">
              <span className="text-4xl font-bold">{p.price}</span>
              <span className="text-muted-foreground">{p.period}</span>
            </div>
            <p className="text-sm text-muted-foreground mb-6">{p.desc}</p>
            <ul className="space-y-3 mb-8 flex-1">
              {p.features.map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm">
                  <Check className="h-4 w-4 text-primary shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <Button
              variant={p.featured ? "hero" : "outline"}
              className="w-full gap-2"
              onClick={() => handleSelectPlan(p.name)}
              disabled={isSubscribed}
            >
              {isSubscribed ? t("precios.subscribed") : p.name === "Institutional" ? t("precios.contact") : t("precios.start")}
              {!isSubscribed && p.name !== "Institutional" && <ArrowRight className="h-4 w-4" />}
            </Button>
          </div>
        ))}
      </div>

      {/* Registration / Payment Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {t("precios.registerFor")} {selectedPlan}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 mt-2">
            <div>
              <label className="text-sm font-medium mb-1 block">{t("precios.name")}</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t("precios.namePlaceholder")}
                required
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-1 block">{t("precios.email")}</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nombre@ejemplo.com"
                required
              />
            </div>
            <div className="rounded-lg border bg-accent/30 p-4">
              <div className="flex justify-between items-center">
                <span className="font-medium">{selectedPlan}</span>
                <span className="font-bold text-primary">
                  {plans.find((p) => p.name === selectedPlan)?.price}
                  {plans.find((p) => p.name === selectedPlan)?.period}
                </span>
              </div>
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? t("precios.processing") : t("precios.confirmPayment")}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
