import { TrendingUp, BarChart3, Shield, Globe, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/i18n/LanguageContext";
import { useNavigate } from "react-router-dom";

export default function Index() {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const stats = [
    { label: t("stats.assets"), value: "$2.4B+" },
    { label: t("stats.investors"), value: "12,000+" },
    { label: t("stats.return"), value: "+15%" },
    { label: t("stats.markets"), value: "40+" },
  ];

  const stories = [
    { name: "GreenTech Fund", return: "+22.4%", description: t("stories.greentech"), icon: TrendingUp },
    { name: "Urban Carbon Credit", return: "+15.8%", description: t("stories.carbon"), icon: BarChart3 },
    { name: "Sustainable Real Estate", return: "+18.2%", description: t("stories.realestate"), icon: Globe },
  ];

  const features = [
    { icon: TrendingUp, title: t("features.ai"), desc: t("features.aiDesc") },
    { icon: Shield, title: t("features.risk"), desc: t("features.riskDesc") },
    { icon: BarChart3, title: t("features.urban"), desc: t("features.urbanDesc") },
    { icon: Globe, title: t("features.global"), desc: t("features.globalDesc") },
  ];

  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-accent/50 to-background" />
        <div className="container relative py-24 md:py-36 flex flex-col items-center text-center gap-6">
          <span className="inline-flex items-center gap-2 rounded-full border bg-background/60 backdrop-blur px-4 py-1.5 text-xs font-medium text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
            {t("hero.badge")}
          </span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight max-w-4xl leading-[1.1]">
            {t("hero.title1")}
            <span className="text-gradient">{t("hero.title2")}</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl">
            {t("hero.subtitle")}
          </p>
          <div className="flex flex-col sm:flex-row gap-3 mt-2">
            <Button variant="hero" size="lg" className="gap-2" onClick={() => {
              navigate("/precios");
              setTimeout(() => {
                document.getElementById("pricing-table")?.scrollIntoView({ behavior: "smooth" });
              }, 100);
            }}>
              {t("hero.cta")} <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="lg">
              {t("hero.demo")}
            </Button>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y bg-card">
        <div className="container py-10 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {stats.map((s) => (
            <div key={s.label} className="animate-fade-in-up">
              <div className="text-2xl md:text-3xl font-bold text-primary">{s.value}</div>
              <div className="text-sm text-muted-foreground mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="container py-20 md:py-28">
        <div className="text-center mb-14">
          <h2 className="text-3xl md:text-4xl font-bold">{t("features.title")}</h2>
          <p className="text-muted-foreground mt-3 max-w-xl mx-auto">{t("features.subtitle")}</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f) => (
            <div key={f.title} className="rounded-xl border bg-card p-6 hover:border-primary/40 transition-colors group">
              <div className="h-10 w-10 rounded-lg bg-accent flex items-center justify-center mb-4 group-hover:bg-primary/10 transition-colors">
                <f.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Success Stories */}
      <section className="bg-card border-y">
        <div className="container py-20 md:py-28">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <span className="text-sm font-medium text-primary">{t("stories.label")}</span>
              <h2 className="text-3xl md:text-4xl font-bold mt-2">{t("stories.title")}</h2>
            </div>
            <div className="flex items-center gap-2 rounded-full bg-success-muted px-4 py-2">
              <TrendingUp className="h-4 w-4 text-primary" />
              <span className="text-sm font-semibold text-primary">+15% {t("stories.growth")}</span>
              <span className="text-xs text-muted-foreground">{t("stories.avg")}</span>
            </div>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {stories.map((s) => (
              <div key={s.name} className="rounded-xl border bg-background p-6 hover:shadow-lg hover:shadow-primary/5 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <div className="h-10 w-10 rounded-lg bg-accent flex items-center justify-center">
                    <s.icon className="h-5 w-5 text-primary" />
                  </div>
                  <span className="text-lg font-bold text-primary">{s.return}</span>
                </div>
                <h3 className="font-semibold mb-2">{s.name}</h3>
                <p className="text-sm text-muted-foreground">{s.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container py-20 md:py-28 text-center">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">{t("cta.title")}</h2>
          <p className="text-muted-foreground mb-8">{t("cta.subtitle")}</p>
          <Button variant="hero" size="lg" className="gap-2" onClick={() => navigate("/precios")}>
            {t("cta.button")} <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </section>
    </>
  );
}
