import { TrendingUp, BarChart3, Shield, Globe, Zap, LineChart } from "lucide-react";
import { useLanguage } from "@/i18n/LanguageContext";

export default function Servicios() {
  const { t } = useLanguage();

  const services = [
    { icon: TrendingUp, title: t("svc.greenInvestment"), desc: t("svc.greenInvestmentDesc") },
    { icon: BarChart3, title: t("svc.urbanData"), desc: t("svc.urbanDataDesc") },
    { icon: Shield, title: t("svc.riskScoring"), desc: t("svc.riskScoringDesc") },
    { icon: Globe, title: t("svc.globalMarket"), desc: t("svc.globalMarketDesc") },
    { icon: Zap, title: t("svc.alerts"), desc: t("svc.alertsDesc") },
    { icon: LineChart, title: t("svc.portfolio"), desc: t("svc.portfolioDesc") },
  ];

  return (
    <div className="container py-16 md:py-24">
      <div className="max-w-2xl mb-14">
        <span className="text-sm font-medium text-primary">{t("servicios.label")}</span>
        <h1 className="text-3xl md:text-5xl font-bold mt-2">{t("servicios.title")}</h1>
        <p className="text-muted-foreground mt-4">{t("servicios.subtitle")}</p>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((s) => (
          <div key={s.title} className="rounded-xl border bg-card p-6 hover:border-primary/40 transition-colors group">
            <div className="h-10 w-10 rounded-lg bg-accent flex items-center justify-center mb-4 group-hover:bg-primary/10 transition-colors">
              <s.icon className="h-5 w-5 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">{s.title}</h3>
            <p className="text-sm text-muted-foreground">{s.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
