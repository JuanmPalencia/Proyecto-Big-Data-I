import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, TrendingDown, DollarSign, PieChart, CheckCircle2, XCircle } from "lucide-react";
import { useLanguage } from "@/i18n/LanguageContext";
import { Badge } from "@/components/ui/badge";
import { SubscriptionGate } from "@/components/SubscriptionGate";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  ScatterChart, Scatter,
  ReferenceLine, Label,
} from "recharts";

interface CityInvestment {
  score: number;
  buySignal: boolean;
  ndvi: number;
  no2: number;
  pib: number;
  reforest: number;
  kuznets: { pib: number; degradation: number }[];
  scatter: { pib: number; no2: number }[];
}

const cityInvestmentData: Record<string, CityInvestment> = {
  Madrid: {
    score: 87, buySignal: true, ndvi: 0.75, no2: 25.3, pib: 42000, reforest: 45,
    kuznets: [
      { pib: 15000, degradation: 30 }, { pib: 20000, degradation: 55 },
      { pib: 25000, degradation: 72 }, { pib: 30000, degradation: 80 },
      { pib: 35000, degradation: 75 }, { pib: 40000, degradation: 60 },
      { pib: 42000, degradation: 48 },
    ],
    scatter: [
      { pib: 15000, no2: 18 }, { pib: 22000, no2: 32 }, { pib: 28000, no2: 38 },
      { pib: 33000, no2: 35 }, { pib: 38000, no2: 28 }, { pib: 42000, no2: 25.3 },
    ],
  },
  Barcelona: {
    score: 82, buySignal: true, ndvi: 0.68, no2: 30.1, pib: 39000, reforest: 38,
    kuznets: [
      { pib: 14000, degradation: 28 }, { pib: 19000, degradation: 50 },
      { pib: 24000, degradation: 68 }, { pib: 29000, degradation: 78 },
      { pib: 34000, degradation: 73 }, { pib: 39000, degradation: 58 },
    ],
    scatter: [
      { pib: 14000, no2: 20 }, { pib: 20000, no2: 35 }, { pib: 26000, no2: 42 },
      { pib: 32000, no2: 38 }, { pib: 39000, no2: 30.1 },
    ],
  },
  Valencia: {
    score: 79, buySignal: true, ndvi: 0.72, no2: 22.8, pib: 35000, reforest: 52,
    kuznets: [
      { pib: 12000, degradation: 25 }, { pib: 17000, degradation: 48 },
      { pib: 22000, degradation: 65 }, { pib: 27000, degradation: 70 },
      { pib: 32000, degradation: 62 }, { pib: 35000, degradation: 45 },
    ],
    scatter: [
      { pib: 12000, no2: 15 }, { pib: 18000, no2: 28 }, { pib: 24000, no2: 35 },
      { pib: 30000, no2: 30 }, { pib: 35000, no2: 22.8 },
    ],
  },
  Sevilla: {
    score: 74, buySignal: false, ndvi: 0.65, no2: 28.7, pib: 31000, reforest: 35,
    kuznets: [
      { pib: 10000, degradation: 22 }, { pib: 15000, degradation: 45 },
      { pib: 20000, degradation: 62 }, { pib: 25000, degradation: 68 },
      { pib: 31000, degradation: 55 },
    ],
    scatter: [
      { pib: 10000, no2: 14 }, { pib: 16000, no2: 30 }, { pib: 22000, no2: 38 },
      { pib: 28000, no2: 33 }, { pib: 31000, no2: 28.7 },
    ],
  },
  Bilbao: {
    score: 92, buySignal: true, ndvi: 0.80, no2: 19.5, pib: 44000, reforest: 60,
    kuznets: [
      { pib: 18000, degradation: 35 }, { pib: 24000, degradation: 58 },
      { pib: 30000, degradation: 74 }, { pib: 36000, degradation: 68 },
      { pib: 40000, degradation: 52 }, { pib: 44000, degradation: 38 },
    ],
    scatter: [
      { pib: 18000, no2: 22 }, { pib: 25000, no2: 34 }, { pib: 32000, no2: 30 },
      { pib: 38000, no2: 24 }, { pib: 44000, no2: 19.5 },
    ],
  },
};

const cities = Object.keys(cityInvestmentData);

const kuznetsConfig = {
  degradation: { label: "Degradación Ambiental", color: "hsl(var(--primary))" },
};
const scatterConfig = {
  no2: { label: "NO₂ (µg/m³)", color: "hsl(var(--primary))" },
};

export default function DashboardInversion() {
  const { t } = useLanguage();
  const [selectedCity, setSelectedCity] = useState("Madrid");

  const data = cityInvestmentData[selectedCity];
  const sortedCities = [...cities].sort(
    (a, b) => cityInvestmentData[b].score - cityInvestmentData[a].score
  );

  const portfolio = [
    { icon: TrendingUp, label: t("di.portfolioValue"), value: "$1,240,000", change: "+8.3%", up: true },
    { icon: DollarSign, label: t("di.monthlyReturn"), value: "$12,400", change: "+2.1%", up: true },
    { icon: PieChart, label: t("di.diversification"), value: "94/100", change: "+3pts", up: true },
    { icon: TrendingDown, label: t("di.riskScore"), value: t("di.riskLow"), change: "-12%", up: false },
  ];

  return (
    <SubscriptionGate>
    <div className="container py-10 md:py-16">
      <div className="max-w-2xl mb-8">
        <span className="text-sm font-medium text-primary">{t("di.label")}</span>
        <h1 className="text-3xl md:text-5xl font-bold mt-2">{t("di.title")}</h1>
        <p className="text-muted-foreground mt-3">{t("di.subtitle")}</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {portfolio.map((m) => (
          <Card key={m.label}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground">{m.label}</CardTitle>
              <m.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{m.value}</div>
              <p className={`text-xs mt-1 ${m.up ? "text-primary" : "text-destructive"}`}>{m.change}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* City Ranking Table */}
      <Card className="mb-8">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>{t("di.cityRanking")}</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">{t("di.selectCity")}:</span>
            <Select value={selectedCity} onValueChange={setSelectedCity}>
              <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
              <SelectContent>
                {cities.map((c) => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-muted-foreground">
                  <th className="text-left py-3 font-medium">#</th>
                  <th className="text-left py-3 font-medium">{t("di.city")}</th>
                  <th className="text-right py-3 font-medium">{t("di.oppScore")}</th>
                  <th className="text-right py-3 font-medium">NDVI</th>
                  <th className="text-right py-3 font-medium">NO₂</th>
                  <th className="text-right py-3 font-medium">{t("di.pib")}</th>
                  <th className="text-center py-3 font-medium">{t("di.tippingFlag")}</th>
                </tr>
              </thead>
              <tbody>
                {sortedCities.map((city, i) => {
                  const c = cityInvestmentData[city];
                  const isSelected = city === selectedCity;
                  return (
                    <tr
                      key={city}
                      onClick={() => setSelectedCity(city)}
                      className={`border-b last:border-0 cursor-pointer transition-colors hover:bg-accent/50 ${isSelected ? "bg-accent" : ""}`}
                    >
                      <td className="py-3 font-medium text-muted-foreground">{i + 1}</td>
                      <td className="py-3 font-medium">{city}</td>
                      <td className="text-right py-3">
                        <span className="font-bold">{c.score}</span>
                      </td>
                      <td className="text-right py-3 text-muted-foreground">{c.ndvi.toFixed(2)}</td>
                      <td className="text-right py-3 text-muted-foreground">{c.no2}</td>
                      <td className="text-right py-3 text-muted-foreground">€{c.pib.toLocaleString()}</td>
                      <td className="text-center py-3">
                        {c.buySignal ? (
                          <Badge variant="outline" className="gap-1 border-primary text-primary">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Buy
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="gap-1 border-destructive text-destructive">
                            <XCircle className="h-3.5 w-3.5" />
                            Hold
                          </Badge>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">{t("du.kuznets")} — {selectedCity}</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={kuznetsConfig} className="h-[280px] w-full">
              <LineChart data={data.kuznets} margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                <XAxis dataKey="pib" tickFormatter={(v) => `€${(v / 1000).toFixed(0)}k`} className="text-[10px]" />
                <YAxis className="text-[10px]" />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="degradation" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))", r: 4 }} />
                <ReferenceLine y={50} stroke="hsl(var(--destructive))" strokeDasharray="4 4">
                  <Label value={t("du.turningPoint")} position="right" className="text-[10px] fill-destructive" />
                </ReferenceLine>
              </LineChart>
            </ChartContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">{t("du.scatterTitle")} — {selectedCity}</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={scatterConfig} className="h-[280px] w-full">
              <ScatterChart margin={{ top: 10, right: 20, bottom: 20, left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                <XAxis dataKey="pib" name="PIB" tickFormatter={(v) => `€${(v / 1000).toFixed(0)}k`} className="text-[10px]" />
                <YAxis dataKey="no2" name="NO₂" unit=" µg/m³" className="text-[10px]" />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Scatter name="NO₂" data={data.scatter} fill="hsl(var(--primary))" fillOpacity={0.8} />
              </ScatterChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>
    </div>
    </SubscriptionGate>
  );
}
