import { createContext, useContext, useState, useEffect, ReactNode } from "react";

const EXTERNAL_SUPABASE_URL = "https://rgumjmbemnbdycmvdqrq.supabase.co/functions/v1";
const STORAGE_KEY = "gtp_auth_user";

export interface AuthUser {
  id: string;
  email: string;
  [key: string]: unknown;
}

interface AuthContextType {
  user: AuthUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  login: async () => {},
  register: async () => {},
  logout: () => {},
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  // Restore session from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch {
      localStorage.removeItem(STORAGE_KEY);
    } finally {
      setLoading(false);
    }
  }, []);

  const persistUser = (u: AuthUser) => {
    setUser(u);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(u));
  };

  const login = async (email: string, password: string) => {
    const res = await fetch(`${EXTERNAL_SUPABASE_URL}/login-lorca`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (!res.ok || data.error) {
      throw new Error(data.error?.message || data.error || data.message || "Error al iniciar sesión");
    }

    // Supabase Auth format: data.user or data.session.user
    const u = data.user ?? data.session?.user;
    if (!u) throw new Error("Respuesta inesperada del servidor");
    persistUser({ id: u.id, email: u.email, ...u });
  };

  const register = async (email: string, password: string) => {
    const res = await fetch(`${EXTERNAL_SUPABASE_URL}/registro-lorca`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();

    if (!res.ok || data.error) {
      throw new Error(data.error?.message || data.error || data.message || "Error al registrarse");
    }

    const u = data.user ?? data.session?.user;
    if (!u) throw new Error("Respuesta inesperada del servidor");
    persistUser({ id: u.id, email: u.email, ...u });
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
